# THE LAST SAVE — Android build (Capacitor)

1. Put Three.js r128 at `www/lib/three.min.js` (download: https://cdnjs.cloudflare.com/ajax/libs/three.js/r128/three.min.js). Needed for offline play; online it falls back to the CDN.
2. `npm install`
3. `npx cap add android`
4. Edit `android/app/src/main/AndroidManifest.xml`: on the `<activity>` add
   `android:screenOrientation="sensorLandscape"`
5. In `android/app/src/main/java/.../MainActivity.java` (optional, true fullscreen): hide system bars, or set theme to NoActionBar.fullscreen.
6. `npx cap sync android` then `npx cap open android`
7. Android Studio: Build > Build APK(s) (debug) or Build > Generate Signed Bundle / APK for distribution.

Also installable as a PWA when hosted over HTTPS (manifest + service worker included).
Edit game code in `www/index.html`; re-run `npx cap sync android` after changes.
